# GrainBrick BETA 1.0 — TrimUI Brick / KNULLI (simple build)

Free public beta; proprietary app code (not open source).
Requires KNULLI with CPython 3.12, Pygame 2.5.2, AArch64 and audio tools. NumPy 1.26.4 for ARM64 is included locally.
Includes NumPy 1.26.4 (ARM64 CPython 3.12) under _vendor/. Does not install or modify system packages. Python 3.12 and Pygame remain KNULLI system dependencies.

Installation: extract archive directly into `/userdata/roms/ports/`.
You should see `GrainBrick beta 1.0.sh` and directory `grainbrick-beta/`.
Refresh PORTS list. Existing beta users: overlay this archive without deleting
`grainbrick-beta`; your own samples, projects, recordings and settings are not replaced by this archive.
One original demo WAV is included. The starter project AMBIENT is included in `grainbrick-beta/projects/`
and uses a demo WAV that is copied to `samples/` on first run.

This revision changes the launcher to use KNULLI system Python. A one-time real
Brick test is necessary, including audio/ORBIX and external Pygame import.
Logs are written to `grainbrick-beta/beta_port_launcher.log`.

Note: older standalone binaries/libraries may remain on a prior installation,
but the new launcher explicitly selects the new CPython module build.
Users can replace/modify the external KNULLI Pygame package with a compatible
version according to its LGPL license.

SoundTouch source code, notices and the MIT bridge are included separately under
`THIRD_PARTY_SOURCES/`. See `THIRD_PARTY_NOTICES.md`.
